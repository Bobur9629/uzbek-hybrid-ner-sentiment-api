# QC report (draft) — synthetic_dataset_10000_v2
Date: 2026-01-01

This report documents quality-control steps applied to the synthetic dataset to improve usability and consistency.

## 1. Goals (based on reviewer/editor comments)
- Ensure **grammatical plausibility** of templates (reduce obviously incorrect constructions).
- Ensure **annotation integrity**: every entity in `entities` appears in the text, and entity/type lists are aligned.
- Ensure **sentiment consistency** between `emoji_score` and `polarity`.
- Provide **open formats** (CSV, JSONL) and basic **descriptive statistics**.

## 2. Implemented QC steps
### 2.1 Template rewrite / diversification
- Replaced a small set of repeated patterns with a broader set of templates (mood, travel, event participation, opinion, org-related actions, date-related actions).
- Added optional **ORG** and **DATE** contexts so the dataset is not restricted to only PER/LOC.

### 2.2 Annotation integrity validation (automatic)
A validation script checks:
- `len(entities) == len(entity_type)` for every row
- each entity string appears verbatim in `text`

**Result:** 0 validation failures (100% pass).

### 2.3 Sentiment consistency
- `polarity` is derived from `emoji_score` using a fixed rule:
  - score > 0.05 => Positive; score < -0.05 => Negative; else Neutral.
- Emoji tokens are selected accordingly.

## 3. Descriptive statistics
See `stats_summary.json` for:
- sentiment distribution
- entity-type mention counts (PER/LOC/ORG/DATE)
- token-length statistics
- source distribution

## 4. Recommended manual review (for final submission)
Even after automated validation, a **native-speaker manual review** is recommended to:
- spot rare unnatural phrasings,
- confirm stylistic adequacy across sources (news/social/dialog),
- verify edge cases in DATE/ORG contexts.

(You may add: number of manually reviewed rows, reviewers' names/roles, and before/after examples.)
