# QC report — manual review summary
Date: 2026-01-01

## Review team
- Reviewer 1: __________________ (role: __________________)
- Reviewer 2: __________________ (role: __________________)

## Dataset version
- Files: `synthetic_dataset_10000_v2.csv` / `synthetic_dataset_10000_v2.jsonl`
- Size: 10,000 rows
- Labels: Sentiment (`Positive/Neutral/Negative`), entities (`PER/LOC/ORG/DATE`)

## Sampling plan
A stratified sample of **1,500** rows was reviewed:
- 500 rows from each `source` category (`synthetic_news`, `synthetic_social`, `synthetic_dialog`)
- The sample includes ORG/DATE-containing sentences to ensure coverage across entity types.

Review sheet:
- `manual_review_sheet_1500_filled_MANUAL.xlsx`

## Checklist (per row)
1) Grammar / fluency  
2) Entity correctness (entity appears in the text; type is appropriate)  
3) Sentiment consistency (emoji and polarity label)  
4) Overall naturalness

## Decisions (from the review sheet)
- Accept: 1304
- Edit: 196
- Reject: 0

### Issue tags frequency (from the review sheet)
{
  "Fluency": 196
}

## Technical validation (consistency checks)
In addition to manual review, a validation script (`scripts/validate_dataset.py`) was used to ensure:
- `len(entities) == len(entity_type)` for each row
- each entity string appears verbatim in the sentence text

## Before/after examples
Please include 20–30 representative examples here (copy from the review sheet):

| id | before | after | issue | decision |
|---:|--------|-------|-------|----------|
|    |        |       |       |          |

## Sign-off
- Reviewer 1: __________________  Date: __________
- Reviewer 2: __________________  Date: __________
