Reviewer notes fields: if no specific comments were recorded for an accepted row, they are marked as 'N/A (no note entered)'.
For edited rows, notes point to 'after_text' where the correction is documented.
