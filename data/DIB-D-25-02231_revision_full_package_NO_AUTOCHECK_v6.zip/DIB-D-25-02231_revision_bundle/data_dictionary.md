# Data dictionary (synthetic_dataset_10000_v6)

**Files**
- `synthetic_dataset_10000_v6.csv` (comma-separated, UTF-8)
- `synthetic_dataset_10000_v6_semicolon.csv` (semicolon-separated, UTF-8-SIG; Excel-friendly)
- `synthetic_dataset_10000_v6.jsonl` (JSON Lines; ML-friendly)
- `synthetic_dataset_10000_v6.xlsx` (Excel)

## Columns
- **id** *(int)*: Row identifier (1..10000).
- **text** *(string)*: Uzbek synthetic sentence. Emojis are **optional** and appear with realistic proportions per `source`.
- **polarity** *(string)*: Sentiment label in {`Positive`, `Neutral`, `Negative`}.
- **entities** *(JSON array stored as string in CSV/XLSX)*: List of entity surface forms appearing in `text`.
- **entity_type** *(JSON array stored as string in CSV/XLSX)*: Labels aligned with `entities` (same length & order).
  - Labels used: `PER`, `LOC`, `ORG`, `DATE`.
- **emoji_score** *(float)*: Sentiment score in [-1,1] consistent with `polarity`. (When an emoji is present, the score matches its polarity class; when no emoji is present, the score still reflects the synthetic sentiment label.)
- **token_count** *(int)*: Whitespace token count of `text`.
- **source** *(string)*: Synthetic style tag (`synthetic_news`, `synthetic_social`, `synthetic_dialog`).

## Notes (v6)
- 0 duplicate sentences (all `text` values are unique).
- ORG/DATE coverage remains balanced per source (see `stats_summary.json`).
- Emoji coverage is source-dependent:
  - news ≈ 15%
  - social ≈ 75%
  - dialog ≈ 55%
