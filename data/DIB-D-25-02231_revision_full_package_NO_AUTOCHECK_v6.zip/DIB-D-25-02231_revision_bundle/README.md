# Synthetic Uzbek dataset (v6)

v6 improvements:
- emojis are no longer present in every sentence; emoji frequency is **source-dependent** (news/social/dialog)
- 0 duplicate sentences
- balanced ORG/DATE coverage per source
- CSV + JSONL exports for non-commercial tooling compatibility

See `stats_summary.json` for distributions.
